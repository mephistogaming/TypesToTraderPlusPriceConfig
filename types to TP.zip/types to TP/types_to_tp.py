# Copyright (C) 2026 MephistoGaming
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

#!/usr/bin/env python3
"""
Build a TraderPlusPriceConfig.json snippet from a DayZ types XML file.

Put this script in its own folder, put one or more types XML files beside it,
then run:

    python types_to_tp.py
"""

from __future__ import annotations

import json
import os
import xml.etree.ElementTree as ET
from collections import OrderedDict
from decimal import Decimal, InvalidOperation
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent
OUTPUT_FILE = SCRIPT_DIR / "TraderPlusPriceConfig_snippet.json"
PRODUCT_TEMPLATE = "{name},1,-1,-1,{buy_price},{sell_price}"
UNCATEGORIZED = "Uncategorized"
CATEGORY_ORDER = [
    "Weapons",
    "Ammo",
    "Weapon Attachments",
    "Explosives",
    "Vests",
    "Jackets and Shirts",
    "Pants",
    "Headgear",
    "Masks and Eyewear",
    "Gloves",
    "Shoes and Boots",
    "Backpacks and Bags",
    "Storage Containers",
    "Food",
    "Drinks",
    "Medical",
    "Tools",
    "Base Building",
    "Vehicles and Boats",
    "Vehicle Parts",
    "Electronics",
    "Crafting Materials",
    "Fishing and Bait",
    "Ghillie and Camouflage",
    "Seasonal and Event Items",
    "Books and Paper",
    "Animals",
    "Infected",
    "Static World Objects",
    "Vehicle Wrecks and Doors",
    "Loot Dispatch",
    UNCATEGORIZED,
]


def contains_any(text: str, words: tuple[str, ...]) -> bool:
    return any(word in text for word in words)


def classify_type(type_name: str, xml_categories: list[str], usages: list[str]) -> str:
    """Guess a useful TraderPlus category from the class name and XML clues."""
    name = type_name.lower()
    joined_clues = " ".join(xml_categories + usages).lower()

    if contains_any(
        name,
        (
            "ammo_",
            "mag_",
            "ammobox",
            "bullet",
            "cartridge",
            "grenade_",
            "grenadebase",
            "rdg",
            "m67",
        ),
    ):
        return "Ammo"

    if contains_any(
        name,
        (
            "suppressor",
            "optic",
            "scope",
            "sight",
            "bayonet",
            "buttstock",
            "bttstck",
            "handguard",
            "hndgrd",
            "rail",
            "compensator",
            "muzzle",
            "weaponlight",
        ),
    ):
        return "Weapon Attachments"

    if contains_any(
        name,
        (
            "mine",
            "explosive",
            "plastic_explosive",
            "remoteexplosive",
            "detonator",
            "grenade",
            "flashbang",
            "smokegrenade",
            "teargas",
            "claymore",
            "ied",
        ),
    ):
        return "Explosives"

    if name.startswith("animal_") or contains_any(
        name, ("wolf", "bear", "deer", "boar", "fox", "caprahircus", "bostaurus")
    ):
        return "Animals"

    if name.startswith("zmb"):
        return "Infected"

    weapon_tokens = (
        "ak", "aug", "b95", "cz", "fal", "fnx", "glock", "izh", "m4", "m16",
        "m79", "mosin", "mp5", "repeater", "ruger", "sks", "svd", "ump", "usp",
        "vss", "winchester", "m249", "m60", "rpk", "pkp", "minimi", "scar",
        "hk", "g3", "g36", "acr", "arx", "famas", "saiga", "vepr", "toz",
        "bizon", "pp19", "mac10", "p90", "mp7", "tmp", "tec9",
        "deagle", "colt", "engraved", "derringer", "flaregun", "magnum",
        "python", "taurus", "smith",
        "rifle", "shotgun", "pistol", "revolver", "crossbow", "bow", "spear",
        "sword", "machete", "knife",
    )
    if (
        any(name.startswith(token) for token in weapon_tokens)
        or contains_any(name, tuple(f"_{token}" for token in weapon_tokens))
        or "weapons" in joined_clues
    ):
        return "Weapons"

    if contains_any(name, ("vest", "platecarrier", "chestholster", "stabvest")):
        return "Vests"

    if contains_any(
        name,
        (
            "jacket",
            "jacky",
            "shirt",
            "hoodie",
            "coat",
            "parka",
            "tshirt",
            "sweater",
            "blouse",
            "torso",
            "gorka",
            "bdujacket",
            "usmcjacket",
        ),
    ):
        return "Jackets and Shirts"

    if contains_any(name, ("pants", "jeans", "shorts", "skirt", "slacks")):
        return "Pants"

    if contains_any(
        name,
        (
            "helmet",
            "hat",
            "baseballcap",
            "flatcap",
            "zmiovkacap",
            "pilotka",
            "beanie",
            "beret",
            "ushanka",
            "balaclava",
            "bandana",
            "head",
        ),
    ):
        return "Headgear"

    if contains_any(
        name,
        (
            "mask",
            "respirator",
            "gasmask",
            "glasses",
            "eyewear",
            "aviator",
            "sportglasses",
            "crookednose",
        ),
    ):
        return "Masks and Eyewear"

    if "glove" in name:
        return "Gloves"

    if contains_any(name, ("boot", "shoe", "sneaker", "wellies", "feet")):
        return "Shoes and Boots"

    if contains_any(
        name,
        ("backpack", "bag", "sack", "pouch", "holster", "belt", "assaultbag", "taloonbag"),
    ):
        return "Backpacks and Bags"

    if contains_any(
        name,
        (
            "barrel",
            "crate",
            "chest",
            "safe",
            "locker",
            "sea_chest",
            "container",
            "case",
            "undergroundstash",
        ),
    ):
        return "Storage Containers"

    if contains_any(
        name,
        (
            "waterbottle",
            "glassbottle",
            "filteringbottle",
            "canteen",
            "sodacan",
            "kvass",
            "vodka",
            "drink",
            "juice",
            "milk",
            "coffee",
            "tea",
        ),
    ):
        return "Drinks"

    if contains_any(
        name,
        (
            "food",
            "meat",
            "steak",
            "fish",
            "pollock",
            "carp",
            "mackerel",
            "caviar",
            "fruit",
            "apple",
            "pear",
            "plum",
            "banana",
            "orange",
            "kiwi",
            "tomato",
            "potato",
            "pepper",
            "zucchini",
            "pumpkin",
            "mushroom",
            "berry",
            "rice",
            "cereal",
            "chips",
            "crackers",
            "can",
            "sardines",
            "tuna",
            "beans",
            "spaghetti",
            "bacon",
            "honey",
            "marmalade",
            "candy",
            "chocolate",
        ),
    ):
        return "Food"

    if contains_any(
        name,
        (
            "bandage",
            "med",
            "medical",
            "vitamin",
            "morphine",
            "epinephrine",
            "charcoal",
            "tetracycline",
            "saline",
            "blood",
            "splint",
            "thermometer",
            "defibrillator",
            "painkiller",
            "purification",
        ),
    ):
        return "Medical"

    if contains_any(
        name,
        (
            "hammer",
            "hatchet",
            "axe",
            "saw",
            "shovel",
            "pickaxe",
            "wrench",
            "pliers",
            "screwdriver",
            "lockpick",
            "compass",
            "map",
            "gps",
            "binocular",
            "rangefinder",
            "fishing",
            "rod",
            "hook",
            "lighter",
            "matches",
            "flashlight",
            "lantern",
            "stove",
            "pot",
            "pan",
            "broom",
            "cauldron",
            "tool",
        ),
    ):
        return "Tools"

    if contains_any(
        name,
        (
            "fence",
            "watchtower",
            "territory",
            "flag",
            "nail",
            "plank",
            "log",
            "wooden",
            "metalplate",
            "wire",
            "combinationlock",
            "camonet",
            "shelter",
            "tent",
        ),
    ):
        return "Base Building"

    if contains_any(
        name,
        (
            "boat_",
            "land_boat",
            "patrolboat",
            "offroad_",
            "hatchback_",
            "sedan_",
            "olga_",
            "sarka_",
            "gunter_",
            "ada_",
            "truck_",
        ),
    ):
        return "Vehicles and Boats"

    if contains_any(
        name,
        (
            "sparkplug",
            "radiator",
            "carbattery",
            "truckbattery",
            "wheel",
            "tire",
            "door_",
            "hood",
            "trunk",
            "hatchback",
            "sedan",
            "olga",
            "sarka",
            "gunter",
            "ada",
            "truck_",
        ),
    ):
        return "Vehicle Parts"

    if contains_any(
        name,
        (
            "battery",
            "radio",
            "transmitter",
            "receiver",
            "cable",
            "charger",
            "electronic",
            "nvggoggles",
            "personalradio",
        ),
    ):
        return "Electronics"

    if contains_any(
        name,
        (
            "rags",
            "rope",
            "leather",
            "ducttape",
            "epoxy",
            "sewingkit",
            "bone",
            "stone",
            "burlap",
            "fabric",
            "lime",
            "guts",
            "pelt",
        ),
    ):
        return "Crafting Materials"

    if contains_any(name, ("worm", "fishingbait", "hook", "netting")):
        return "Fishing and Bait"

    if contains_any(name, ("ghillie", "camo", "camouflage")):
        return "Ghillie and Camouflage"

    if contains_any(
        name,
        (
            "christmas",
            "easter",
            "halloween",
            "bonfire",
            "gift",
            "candycane",
            "tree",
        ),
    ):
        return "Seasonal and Event Items"

    if contains_any(name, ("book", "paper", "note")):
        return "Books and Paper"

    if name.startswith("staticobj_") or contains_any(
        name, ("contaminatedarea", "static_", "roadblock", "train_wagon", "supplybox")
    ):
        return "Static World Objects"

    if contains_any(name, ("wreck", "wreck_", "doors_", "door_", "cargo", "civilian")):
        return "Vehicle Wrecks and Doors"

    if "lootdispatch" in joined_clues:
        return "Loot Dispatch"

    if "food" in joined_clues:
        return "Food"
    if "clothes" in joined_clues:
        return "Jackets and Shirts"
    if "tools" in joined_clues:
        return "Tools"
    if "containers" in joined_clues:
        return "Storage Containers"
    if "explosives" in joined_clues:
        return "Explosives"

    return UNCATEGORIZED


def choose_xml_file() -> Path:
    xml_files = sorted(SCRIPT_DIR.glob("*.xml"))
    if not xml_files:
        raise SystemExit(
            "No XML files found. Put your types.xml file in this folder and run again."
        )

    if len(xml_files) == 1:
        print(f"Using XML file: {xml_files[0].name}")
        return xml_files[0]

    print("XML files found:")
    for index, path in enumerate(xml_files, start=1):
        print(f"  {index}. {path.name}")

    while True:
        choice = input("Choose a file number: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(xml_files):
            return xml_files[int(choice) - 1]
        print("Please enter one of the listed numbers.")


def parse_types_by_category(xml_file: Path) -> "OrderedDict[str, list[str]]":
    try:
        root = ET.parse(xml_file).getroot()
    except ET.ParseError as error:
        raise SystemExit(f"Could not parse {xml_file.name}: {error}") from error

    grouped: dict[str, list[str]] = {category_name: [] for category_name in CATEGORY_ORDER}

    for type_node in root.findall(".//type"):
        type_name = (type_node.get("name") or "").strip()
        if not type_name:
            continue

        xml_categories = [
            (node.get("name") or "").strip()
            for node in type_node.findall("category")
            if node.get("name")
        ]
        usages = [
            (node.get("name") or "").strip() for node in type_node.findall("usage") if node.get("name")
        ]
        guessed_category = classify_type(type_name, xml_categories, usages)
        grouped.setdefault(guessed_category, []).append(type_name)

    categories: "OrderedDict[str, list[str]]" = OrderedDict(
        (category_name, items)
        for category_name, items in grouped.items()
        if items
    )

    if not categories:
        raise SystemExit("No <type name=\"...\"> entries were found in that XML file.")

    return categories


def valid_price(value: str) -> bool:
    try:
        Decimal(value)
    except InvalidOperation:
        return False
    return True


def parse_price_pair(value: str) -> tuple[str, str] | None:
    if "," not in value:
        return None

    buy_str, sell_str = value.split(",", 1)
    buy_str = buy_str.strip()
    sell_str = sell_str.strip()
    if valid_price(buy_str) and valid_price(sell_str):
        return buy_str, sell_str
    return None


def clear_screen() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def print_line() -> None:
    print("=" * 72)


def print_header(title: str) -> None:
    clear_screen()
    print_line()
    print(f" {title}")
    print_line()
    print()


def prompt_price_pair(prompt: str) -> tuple[str, str]:
    while True:
        answer = input(prompt).strip()
        parsed = parse_price_pair(answer)
        if parsed is not None:
            return parsed
        print("Please enter prices like this: 1000,500")
        print("That means BuyPrice 1000 and SellPrice 500.")
        print()


def print_category_summary(categories: "OrderedDict[str, list[str]]") -> None:
    print("Categories found:")
    print("-" * 72)
    for index, (category_name, items) in enumerate(categories.items(), start=1):
        print(f"{index:>2}. {category_name:<30} {len(items):>5} items")
    print("-" * 72)


def choose_pricing_mode() -> str:
    print()
    print("Choose how you want to price the items:")
    print()
    print("  1. Category pricing")
    print("     Set a fallback price, then override only the categories you want.")
    print()
    print("  2. One default price for everything")
    print("     Every item gets the same BuyPrice,SellPrice.")
    print()
    print("  3. Price each item one by one")
    print("     Go through individual item names and set prices manually.")
    print()

    while True:
        choice = input("Enter 1, 2, or 3: ").strip()
        if choice in {"1", "2", "3"}:
            return choice
        print("Please type 1, 2, or 3.")


def ask_category_prices(
    categories: "OrderedDict[str, list[str]]",
) -> dict[str, dict[str, tuple[str, str]]]:
    print_header("Category Pricing")
    print("Set a fallback price first if you want every item included.")
    print("Then enter a different BuyPrice,SellPrice only for categories you want to change.")
    print()
    print("Example price: 1000,500")
    print()
    print("At each category:")
    print("  - Press Enter to use the fallback price")
    print("  - Enter BuyPrice,SellPrice to override that category")
    print("  - Type skip to leave that category out")
    print()

    prices: dict[str, dict[str, tuple[str, str]]] = {}
    fallback_price: tuple[str, str] | None = None

    while True:
        answer = input("Fallback price for all categories, or Enter for none: ").strip()
        if not answer:
            break

        parsed = parse_price_pair(answer)
        if parsed is not None:
            fallback_price = parsed
            break

        print("Please enter prices like this: 1000,500, or press Enter for no fallback.")

    print()

    for category_name, items in categories.items():
        while True:
            answer = input(f"{category_name} ({len(items)} items): ").strip()
            if not answer:
                if fallback_price is not None:
                    prices[category_name] = {
                        item_name: fallback_price for item_name in items
                    }
                    print(f"Used fallback price for {category_name}.")
                else:
                    print(f"Skipped {category_name}.")
                break

            if answer.lower() == "skip":
                print(f"Skipped {category_name}.")
                break

            parsed = parse_price_pair(answer)
            if parsed is None:
                print("Please enter prices like this: 1000,500, press Enter, or type skip.")
                continue

            prices[category_name] = {item_name: parsed for item_name in items}
            break

    return prices


def ask_default_prices(
    categories: "OrderedDict[str, list[str]]",
) -> dict[str, dict[str, tuple[str, str]]]:
    print_header("One Default Price")
    print("Every item in every category will use the same BuyPrice,SellPrice.")
    print("Example: 1000,500")
    print()

    price_pair = prompt_price_pair("Default price for all items: ")
    return {
        category_name: {item_name: price_pair for item_name in items}
        for category_name, items in categories.items()
    }


def ask_item_prices(
    categories: "OrderedDict[str, list[str]]",
) -> dict[str, dict[str, tuple[str, str]]]:
    print_header("Individual Item Pricing")
    print("You will go category by category, then item by item.")
    print("You can set one fallback price for every item before starting.")
    print("For each category, you can also set a temporary category default.")
    print("Then press Enter on an item to use the best available default.")
    print("Type skip on an item to leave that item out.")
    print()

    prices: dict[str, dict[str, tuple[str, str]]] = {}
    fallback_price: tuple[str, str] | None = None

    while True:
        answer = input("Fallback price for every item, or Enter for none: ").strip()
        if not answer:
            break

        parsed = parse_price_pair(answer)
        if parsed is not None:
            fallback_price = parsed
            break

        print("Please enter prices like this: 1000,500, or press Enter for no fallback.")

    print()

    for category_name, items in categories.items():
        print_line()
        print(f"{category_name} - {len(items)} items")
        print_line()
        print("Options:")
        print("  - Enter a category default like 1000,500")
        print("  - Press Enter to use the fallback price for this category")
        print("  - Type skip to skip this whole category")
        print()

        while True:
            answer = input(f"Default for {category_name}: ").strip()
            if answer.lower() == "skip":
                print(f"Skipped {category_name}.")
                print()
                break
            if not answer:
                category_default = fallback_price
                break
            parsed = parse_price_pair(answer)
            if parsed is not None:
                category_default = parsed
                break
            print("Please enter prices like 1000,500, press Enter, or type skip.")

        if answer.lower() == "skip":
            continue

        category_prices: dict[str, tuple[str, str]] = {}
        sorted_items = sorted(dict.fromkeys(items), key=str.lower)

        for index, item_name in enumerate(sorted_items, start=1):
            while True:
                if category_default is None:
                    prompt = f"[{index}/{len(sorted_items)}] {item_name}: "
                else:
                    buy_price, sell_price = category_default
                    prompt = (
                        f"[{index}/{len(sorted_items)}] {item_name} "
                        f"(Enter = {buy_price},{sell_price}): "
                    )

                answer = input(prompt).strip()
                if not answer:
                    if category_default is not None:
                        category_prices[item_name] = category_default
                    break

                if answer.lower() == "skip":
                    break

                parsed = parse_price_pair(answer)
                if parsed is None:
                    print("Please enter prices like 1000,500, press Enter, or type skip.")
                    continue

                category_prices[item_name] = parsed
                break

        if category_prices:
            prices[category_name] = category_prices
        print()

    return prices


def ask_prices(categories: "OrderedDict[str, list[str]]") -> dict[str, dict[str, tuple[str, str]]]:
    print_header("Types XML to TraderPlus")
    print("Your XML has been scanned and sorted into easy pricing categories.")
    print()
    print_category_summary(categories)
    mode = choose_pricing_mode()

    if mode == "1":
        return ask_category_prices(categories)
    if mode == "2":
        return ask_default_prices(categories)
    return ask_item_prices(categories)

def build_snippet(
    categories: "OrderedDict[str, list[str]]", prices: dict[str, dict[str, tuple[str, str]]]
) -> dict[str, list[dict[str, object]]]:
    trader_categories: list[dict[str, object]] = []

    for category_name, items in categories.items():
        item_prices = prices.get(category_name)
        if not item_prices:
            continue

        products = []
        for item_name in sorted(dict.fromkeys(items), key=str.lower):
            price_pair = item_prices.get(item_name)
            if price_pair is None:
                continue
            buy_price, sell_price = price_pair
            products.append(
                PRODUCT_TEMPLATE.format(
                    name=item_name,
                    buy_price=buy_price,
                    sell_price=sell_price,
                )
            )

        if not products:
            continue

        trader_categories.append(
            {
                "CategoryName": category_name,
                "Products": products,
            }
        )

    return {"TraderCategories": trader_categories}


def main() -> int:
    os.chdir(SCRIPT_DIR)

    xml_file = choose_xml_file()
    categories = parse_types_by_category(xml_file)

    total_items = sum(len(items) for items in categories.values())
    print()
    print(f"Found {total_items} type entries.")
    print(f"Auto-detected {len(categories)} TraderPlus-style categories.")
    input("Press Enter to continue to pricing...")

    prices = ask_prices(categories)
    if not prices:
        print("No prices were entered, so no snippet was created.")
        return 0

    snippet = build_snippet(categories, prices)
    OUTPUT_FILE.write_text(json.dumps(snippet, indent=2), encoding="utf-8")

    category_count = len(snippet["TraderCategories"])
    product_count = sum(len(category["Products"]) for category in snippet["TraderCategories"])
    print()
    print(f"Created: {OUTPUT_FILE}")
    print(f"Included {category_count} categories and {product_count} products.")
    print("Copy the TraderCategories entries into your TraderPlusPriceConfig.json.")
    print("Written / Developed by MephistoGaming.")
    input("Press Enter to close...")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
